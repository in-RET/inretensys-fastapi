##  @package components
#   Documentation for this package.
#
#   Collection of all possible components.
